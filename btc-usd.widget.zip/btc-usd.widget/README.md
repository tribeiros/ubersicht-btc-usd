# Übersicht Widget - BTC/USD

![Screenshot](https://github.com/tribeiros/ubersicht-btc-usd/blob/master/screenshot.png)
